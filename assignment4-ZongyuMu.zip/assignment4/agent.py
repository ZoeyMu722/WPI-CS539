import numpy as np
from state import State, WAIT_ACTION

########## EDIT THESE PARAMETERS ##########
INIT_L2_PENALTY = 0.01
INIT_LEARNING_RATE = 0.1
INIT_DISCOUNT_FACTOR = 0.9
###########################################


class GameScheduler:
    def __init__(self, n_episodes: int) -> None:
        self.n_episodes = n_episodes

    def __call__(self, episode: int | None) -> dict[str, int]:
      
        if episode is None:
           
            return dict(n_rows=5, n_cols=5, n_players=3, n_steps=10)
    
        frac = (episode + 1) / self.n_episodes
        n_rows = int(3 + 2 * frac)
        n_cols = int(3 + 2 * frac)
        n_players = 2
        n_steps = int(5 + 5 * frac)
        return dict(n_rows=n_rows, n_cols=n_cols, n_players=n_players, n_steps=n_steps)


class RewardFunction:
    def __init__(self, player: str) -> None:
        self.player = player

    def __call__(self, state: State, action: int, next_state: State) -> float:
       
        reward = 0.0
        if next_state.just_tagged:
            if next_state.tagged_player == self.player:
                reward -= 1.0
            else:
                reward += 1.0
        return float(reward)


class FeatureFunction:
    def __init__(self, player: str) -> None:
        self.player = player
       
        self.N_FEATURES = 5

    def __call__(self, state: State) -> np.ndarray:
        me = self.player
        if me not in state.player_positions:
            return np.zeros(self.N_FEATURES, dtype=np.float32)
        my_pos = np.array(state.player_positions[me])
        others = [np.array(p) for k, p in state.player_positions.items() if k != me]
        if others:
            dists = [np.linalg.norm(my_pos - o) for o in others]
            min_dist = min(dists)
        else:
            min_dist = 0.0
        tagged_flag = 1.0 if state.tagged_player == me else 0.0
        just_tagged_flag = 1.0 if state.just_tagged else 0.0
        bias = 1.0
        features = np.array([bias, my_pos[0], my_pos[1], min_dist, tagged_flag + just_tagged_flag], dtype=np.float32)
        return features


class Agent:
    def __init__(
        self,
        player: str,
        l2_penalty: float,
        learning_rate: float,
        discount_factor: float,
        reward_function: RewardFunction,
        feature_function: FeatureFunction,
    ) -> None:
        self.player = player
        self.l2_penalty = l2_penalty
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.reward_function = reward_function
        self.feature_function = feature_function

      
        self.theta: dict[int, np.ndarray] = {}
       
        self.epsilon = 0.1

    def ensure_action(self, action: int) -> None:
        if action not in self.theta:
            n = self.feature_function.N_FEATURES
            self.theta[action] = np.zeros(n, dtype=np.float32)

    def calculate_q_value(self, state: State, action: int) -> float:
        self.ensure_action(action)
        phi = self.feature_function(state)
        return float(np.dot(self.theta[action], phi))

    def calculate_state_value(self, state: State) -> float:
        legal_actions = state.get_legal_actions()
        if not legal_actions:
            return 0.0
        q_values = [self.calculate_q_value(state, a) for a in legal_actions]
        return float(max(q_values))

    def calculate_gradient(
         self,
         state: State,
         action: int,
         q_value: float,
         target_q_value: float,
    ) -> np.ndarray:
         phi = self.feature_function(state)
    
         l2_term = self.l2_penalty * (self.theta[action] + 1e-4)
         grad = (q_value - target_q_value) * phi + l2_term
         return grad


    def select_action(self, state: State, training: bool) -> int:
        legal_actions = state.get_legal_actions()
        if not legal_actions:
            return WAIT_ACTION
        if training and np.random.rand() < self.epsilon:
            return np.random.choice(legal_actions)
       
        q_values = [self.calculate_q_value(state, a) for a in legal_actions]
        best_idx = int(np.argmax(q_values))
        return legal_actions[best_idx]

    def update_model(
        self,
        state: State,
        action: int,
        next_state: State,
        terminal: bool,
    ) -> None:
        self.ensure_action(action)
        reward = self.reward_function(state, action, next_state)
        q_value = self.calculate_q_value(state, action)
        if terminal:
            target_q_value = reward
        else:
            target_q_value = reward + self.discount_factor * self.calculate_state_value(next_state)
        grad = self.calculate_gradient(state, action, q_value, target_q_value)
        self.theta[action] -= self.learning_rate * grad

