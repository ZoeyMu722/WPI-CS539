import numpy as np

# --------------------------
def compute_Phi(x, p):
    
    x = np.asarray(x).flatten()  
    n = x.shape[0]
    Phi = np.zeros((n, p))
    for i in range(p):
        Phi[:, i] = x ** i
    return Phi

# --------------------------
def compute_yhat(Phi, w):
   
    Phi = np.atleast_2d(Phi)
    w = np.asarray(w).flatten()
    yhat = Phi.dot(w)
    return yhat

# --------------------------
def compute_L(yhat, y):
   
    yhat = np.asarray(yhat).flatten()
    y = np.asarray(y).flatten()
    L = 0.5 * np.mean((yhat - y) ** 2)
    return L

# --------------------------
def compute_dL_dw(y, yhat, Phi):
    
    y = np.asarray(y).flatten()
    yhat = np.asarray(yhat).flatten()
    Phi = np.atleast_2d(Phi)
    n = y.shape[0]
    dL_dw = (1/n) * Phi.T.dot(yhat - y)
    return dL_dw

# --------------------------
def update_w(w, dL_dw, alpha=0.001):
  
    w = np.asarray(w).flatten()
    dL_dw = np.asarray(dL_dw).flatten()
    w = w - alpha * dL_dw
    return w

# --------------------------
def train(X, Y, alpha=0.001, n_epoch=100):
    
    X = np.atleast_2d(X)
    Y = np.asarray(Y).flatten()
    w = np.zeros(X.shape[1])  # shape (n_features,)

    for _ in range(n_epoch):
        yhat = compute_yhat(X, w)
        dL_dw = compute_dL_dw(Y, yhat, X)
        w = update_w(w, dL_dw, alpha)

    return w


