import numpy as np
from linear_regression import *
from sklearn.datasets import make_regression

# Data generation
n_samples = 200
X, y = make_regression(n_samples=n_samples, n_features=4, noise=0.0, random_state=1)
y = np.array(y)
X = np.array(X)

# Train/test split
Xtrain, Ytrain = X[::2], y[::2]
Xtest, Ytest = X[1::2], y[1::2]

# Hyperparameters
alpha = 0.01
n_epoch = 10000

# Train using train()
w = train(Xtrain, Ytrain, alpha=alpha, n_epoch=n_epoch)

# Evaluate
Ytrain_pred = compute_yhat(Xtrain, w)
Ytest_pred = compute_yhat(Xtest, w)
train_loss = compute_L(Ytrain_pred, Ytrain)
test_loss = compute_L(Ytest_pred, Ytest)

print("\n=== Final Results ===")
print("Alpha (learning rate):", alpha)
print("Number of epochs:", n_epoch)
print("Train Loss:", train_loss)
print("Test Loss:", test_loss)
print("Learned weights w:", w)
