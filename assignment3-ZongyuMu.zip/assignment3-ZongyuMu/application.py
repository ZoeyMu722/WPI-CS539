import numpy as np
from soft_svm import *
from sklearn.datasets import make_classification


n_samples = 200
X, y = make_classification(n_samples=n_samples, n_features=4, n_informative=4,
                           n_redundant=0, n_clusters_per_class=1, random_state=1)
X = (X - X.mean(axis=0)) / X.std(axis=0)
y = 2*y - 1
from sklearn.model_selection import train_test_split
Xtrain, Xtest, Ytrain, Ytest = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)




C = 3.0
alpha = 0.01
n_epoch = 1500


w = train(Xtrain, Ytrain, C=C, alpha=alpha, n_epoch=n_epoch)


Ytrain_hat = predict(Xtrain, w)
Ytest_hat = predict(Xtest, w)


train_acc = np.mean(Ytrain_hat == Ytrain)
test_acc = np.mean(Ytest_hat == Ytest)


J_test = compute_J(Xtest, Ytest, w, C=C)

print("Parameters:")
print(f"C = {C}, alpha = {alpha}, n_epoch = {n_epoch}")
print(f"Train Accuracy: {train_acc*100:.2f}%")
print(f"Test Accuracy: {test_acc*100:.2f}%")
print(f"Objective on Test Set: {J_test:.3f}")


