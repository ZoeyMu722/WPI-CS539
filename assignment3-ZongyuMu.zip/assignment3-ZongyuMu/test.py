from soft_svm import *
import numpy as np
import sys
'''
Unit test:
This file includes unit tests for soft_svm.py.
Test the correctness of your code by typing `pytest -v test.py` in the terminal.
'''

#-------------------------------------------------------------------------
def test_python_version():
    ''' ----------- Problem 1 (70 points in total)---------------------'''
    assert sys.version_info[0]==3


#-------------------------------------------------------------------------
def test_compute_margins_and_s():
    '''(20 points) compute_margins / compute_s'''
    X = np.array([[1.0, 2.0],
                  [2.0, -1.0],
                  [-1.0, -1.0]])
    w = np.array([0.5, -0.6])
    y = np.array([1, 1, -1])
    margins = compute_margins(X, y, w)
    assert margins.shape == (3,)
    assert np.allclose(margins, [-0.7, 1.6, -0.1], atol=1e-3)
    s = compute_s(margins)
    assert s.dtype in (np.int64, np.int32, np.float64, np.float32)
    assert np.allclose(s, [1, 0, 1], atol=1e-8)


#-------------------------------------------------------------------------
def test_compute_J():
    '''(10 points) compute_J'''
    X = np.array([[1.0, 2.0],
                  [2.0, -1.0],
                  [-1.0, -1.0]])
    w = np.array([0.5, -0.6])
    y = np.array([1, 1, -1])
    C = 2.0

    J = compute_J(X, y, w, C=C)
    assert np.allclose(J, 5.905, atol=1e-3)


#-------------------------------------------------------------------------
def test_compute_dJ_dw():
    '''(10 points) compute_dJ_dw'''
    X = np.array([[1.0, 2.0],
                  [2.0, -1.0],
                  [-1.0, -1.0]])
    w = np.array([0.5, -0.6])
    y = np.array([1, 1, -1])
    C = 2.0

    dJ = compute_dJ_dw(X, y, w, C=C)
    assert np.allclose(dJ, [-3.5, -6.6], atol=1e-3)


#-------------------------------------------------------------------------
def test_update():
    '''(10 points) update_w'''
    w = np.array([0.5, -0.6])

    w1 = update_w(w.copy(), np.array([-3.5, -6.6]), alpha=0.1)
    assert np.allclose(w1, [0.85, 0.06], atol=1e-3)


#-------------------------------------------------------------------------
def test_train_and_predict():
    '''(20 points) train / predict'''
    Xtrain = np.array([[ 2.,  2.],
                       [ 2.,  0.],
                       [ 0.,  2.],
                       [-2., -2.],
                       [-2.,  0.],
                       [ 0., -2.]])
    Ytrain = np.array([ 1, 1, 1, -1, -1, -1])
    w = train(Xtrain, Ytrain, C=1.0, alpha=0.1, n_epoch=50)
    Yhat = predict(Xtrain, w)
    assert Yhat.shape == (6,)
    assert np.all(Yhat == Ytrain)
