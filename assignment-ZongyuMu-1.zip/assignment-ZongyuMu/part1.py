import numpy as np
import csv
from collections import Counter


class Node:
    def __init__(self, X, Y, i=None, C=None, isleaf=False, p=None):
        self.X = X
        self.Y = Y
        self.i = i
        self.C = C
        self.isleaf = isleaf
        self.p = p


class Tree:
    @staticmethod
    def entropy(Y):
        if len(Y) == 0:
            return 0.0
        counter = Counter(Y)
        probs = [count / len(Y) for count in counter.values()]
        return -sum(p * np.log2(p) for p in probs)

    @staticmethod
    def conditional_entropy(Y, X):
        if len(Y) == 0 or len(X) != len(Y):
            return 0.0
        grouped = {}
        for x, y in zip(X, Y):
            grouped.setdefault(x, []).append(y)
        return sum(len(vals) / len(Y) * Tree.entropy(vals) for vals in grouped.values())

    @staticmethod
    def information_gain(Y, X):
        if len(X) == 0 or len(X) != len(Y):
            return 0.0
        return Tree.entropy(Y) - Tree.conditional_entropy(Y, X)

    @staticmethod
    def best_attribute(X, Y):
        p, n = X.shape
        if p == 0 or n == 0 or n != len(Y):
            return 0
        gains = [Tree.information_gain(Y, X[i]) for i in range(p)]
        return int(np.argmax(gains))

    @staticmethod
    def split(X, Y, i):
        values_index = {}
        for idx, val in enumerate(X[i]):
            values_index.setdefault(val, []).append(idx)

        C = {}
        for key, idxs in values_index.items():
            sub_X = X[:, idxs]
            sub_Y = Y[idxs]
            C[key] = Node(sub_X, sub_Y)
        return C

    @staticmethod
    def stop1(Y):
        return len(Y) == 0 or all(y == Y[0] for y in Y)

    @staticmethod
    def stop2(X):
        if X.shape[1] <= 1:
            return True
        return all(np.all(row == row[0]) for row in X)

    @staticmethod
    def most_common(Y):
        counter = Counter(Y)
        return counter.most_common(1)[0][0]

    @staticmethod
    def build_tree(t):
        t.p = Tree.most_common(t.Y)

        if Tree.stop1(t.Y) or Tree.stop2(t.X):
            t.isleaf = True
            t.i = None
            t.C = None
            return

        t.isleaf = False
        t.i = Tree.best_attribute(t.X, t.Y)
        t.C = Tree.split(t.X, t.Y, t.i)

        for child in t.C.values():
            Tree.build_tree(child)

    @staticmethod
    def train(X, Y):
        t = Node(X, Y)
        Tree.build_tree(t)
        return t

    @staticmethod
    def inference(t, x):
        if t.isleaf:
            return t.p
        attr_value = x[t.i]
        if attr_value in t.C:
            return Tree.inference(t.C[attr_value], x)
        return t.p

    @staticmethod
    def predict(t, X):
        return np.array([Tree.inference(t, X[:, i]) for i in range(X.shape[1])])

    @staticmethod
    def load_dataset(filename='data1.csv'):
        rows = []
        with open(filename, 'r') as f:
            reader = csv.reader(f)
            next(reader, None)
            rows.extend(reader)

        if not rows:
            return np.array([]), np.array([])

        Y = np.array([row[0] for row in rows])
        X = np.array([row[1:] for row in rows]).T
        return X, Y



