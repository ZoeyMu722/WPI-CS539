# Part 1: Implement Decision Tree with Discrete Attributes (60 pts)

In this assignment, you will implement the decision tree algorithm for a
classification problem in Python 3. We provide the following three
files:

-   **data1.csv** -- Load the file, build a tree, and evaluate its
    performance.\
    The first row of the file is the header (including the names of the
    attributes).\
    In the remaining rows, each row represents an instance/example.\
    The first column of the file is the target label.

-   **part1.py** -- Implement several functions.\
    **Do not change the input and output of the functions.**

-   **test1.py** -- Includes unit tests.\
    Run this file by typing `pytest -v test1.py` in the terminal to
    check whether all functions are properly implemented.\
    No modification is required.

------------------------------------------------------------------------

# Part 2: Credit Risk Prediction (40 pts)

Assume you work for a credit card company. Given the sample credit
dataset (`credit.txt`) as a training set, your job is to build a
decision tree and make risk predictions of individuals. The target/class
variable is **credit risk** described as *high* or *low*. Features are:
debt, income, marital status, property ownership, and gender.

## Task 2-1

-   Draw your decision tree and report it.\
    You may use visualization tools (e.g., Graphviz) or use text.\
    You might find it easier if you turn the decision tree on its side,
    and use indentation to show levels of the tree as it grows from the
    left.

    Example:

        outlook = sunny
        |  humidity = high: no
        |  humidity = normal: yes
        outlook = overcast: yes
        outlook = rainy
        |  windy = TRUE: no
        |  windy = FALSE: yes

-   Apply the decision tree to determine the credit risk of the
    following individuals:

      Name   Debt   Income   Married?   Owns Property   Gender
      ------ ------ -------- ---------- --------------- --------
      Tom    low    low      no         Yes             Male
      Ana    low    medium   yes        Yes             Female

-   Report a snapshot of your decision tree and predicted credit risk of
    Tom and Ana.

## Task 2-2

-   Explain how your decision tree changes if Sofia's credit risk is
    *high* instead of *low* as recorded in the training data.
-   Given the decision tree constructed from the original dataset, if
    existing, name any feature not playing a role in the decision tree.
